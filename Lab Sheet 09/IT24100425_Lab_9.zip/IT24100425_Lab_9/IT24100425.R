setwd("C:\\Users\\nadun\\OneDrive\\Desktop\\IT24100425_Lab_9")
getwd()

# Exercise

# Q - 1
# (part i)
b_time <- rnorm(25, mean = 45, sd = 2)
print(b_time)

# (part ii)
t_result <- t.test(b_time, mu = 46, alternative = "less")
print(t_result)


