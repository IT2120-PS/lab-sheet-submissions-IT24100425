setwd("C:\\Users\\it24100425\\Desktop\\IT24100425")
getwd()


branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")


fix(branch_data)

boxplot(branch_data$Sales_X1, main = "Boxplot for Sales",ylab = "Sales",outline = TRUE ,horizontal = TRUE)


summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)

find_outliers<-function(x){
  Q1<-quantile(x,0.25)
  Q3<-quantile(x,0.75)
  IQR<- Q3-Q1
  
  ub<-q3+1.5*iqr
  lb<- q1-1.5 *iqr
  
  outliers <-x[x<lb |x> ub]
  
  
if(length(outliers)==0){
    return ("no outliers detected")
}else{
  return(sort(outliers))
}
    
  
}


